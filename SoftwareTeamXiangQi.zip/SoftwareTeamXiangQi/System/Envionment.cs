﻿namespace System
{
    internal class Envionment
    {
        internal static void Exit(int v)
        {
            throw new NotImplementedException();
        }
    }
}